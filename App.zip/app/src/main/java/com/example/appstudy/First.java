package com.example.appstudy;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class First extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first);
    }
}
